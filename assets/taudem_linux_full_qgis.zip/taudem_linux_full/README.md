# TauDEM Linux Full Processing (v0.2.0)

Experimental **original** QGIS 3 Processing plugin for local binaries from the TauDEM `Develop` branch. It is **not** a port of the Not-So-QT-DEM repository: that upstream's sources were not available for direct inspection during this build. It is also **not** part of the official TauDEM project.

## Installation (TUXEDO OS, Ubuntu, Mint)

Prerequisites: working QGIS 3.x, TauDEM built at `~/apps/taudem/bin`, OpenMPI (`mpiexec`). This plugin does not compile TauDEM and requires no system-level packages beyond those already used by your working TauDEM setup.

- QGIS → Plugins → Manage and Install Plugins → Install from ZIP → select `taudem_linux_full_qgis.zip`.
- If QGIS warns about installing a ZIP, confirm. Enable **TauDEM Linux Full Processing** under Installed. Restart QGIS if necessary.
- Alternatively run `bash install_taudem_linux_full.sh` next to the ZIP to install into the default QGIS profile. Run with `QGIS_PROFILE=myprofile` for a different profile.
- Open Processing Toolbox → **TauDEM Linux (Develop)**. There should be **37** algorithms. The old `taudem_local` plugin is left unchanged.

For custom installations set environment variables **before starting QGIS**:

```bash
export TAUDEM_BIN_DIR="$HOME/apps/taudem/bin"
export TAUDEM_MPIEXEC="$(command -v mpiexec)"
qgis
```

## Check in QGIS Python console

```python
p = QgsApplication.processingRegistry().providerById('taudem_linux_full')
print(p.name() if p else 'NOT LOADED')
print(len(p.algorithms()) if p else 0)
print([a.id() for a in p.algorithms()] if p else [])
```

Try `Pit Remove` with a small GeoTIFF DEM. Follow with `D8 Flow Directions` and `D8 Contributing Area`. Watch Processing log for the precise MPI command.

## Features

- 37 algorithm wrappers corresponding to executables in `TauDEM/Develop/src/CMakeLists.txt` (2026-11-08); 37 *registered* algorithms does **not** mean all have been executed successfully.
- Input rasters, vectors, files, numeric parameters and booleans; output rasters, vectors and text/tables.
- OpenMPI execution on Linux with explicit process count, streaming log messages, exit status validation, cancellation of MPI process groups.
- Vector inputs exported to temporary ESRI Shapefiles, GeoPackage output converted from TauDEM intermediate Shapefiles.
- Raster files must exist on disk (local GeoTIFF recommended). Vector outputs must be local Shapefiles or GeoPackages. External table formats may require precise TauDEM-specific contents.
- Only the bundled Python code is installed; no Windows executables or TauDEM binaries.

## Limitations and status

- **Not tested with a running QGIS or TauDEM binary** in the build environment: import/registration was smoke-tested via Python test doubles, and subprocess arguments tested with fake binaries.
- Many CLI definitions reflect upstream command-line docs and selected source files but have **not undergone per-tool numerical validation**. Especially review advanced flood, SINMAP, and regional workflows before research or teaching use.
- No automatic reproject/resample/align for rasters, no backend for remote WMS/memory layers. TauDEM expects compatible inputs with identical extents/resolution where the algorithm requires them.
- QGIS may offer database/memory vector sinks; only `.shp` and `.gpkg` file outputs are implemented.
- Run `siregion` with either input polygon or region raster, never both. Avoid field `FID` as region identifier.
- Existing output files may need deletion if a driver refuses to overwrite.

## Support / debugging

If an algorithm fails, copy the Processing log's `TauDEM command: ...` line and exit/error output. Verify it first in a terminal with small test data. Examine QGIS Python log for registration errors. If the GUI does not show the plugin, check the path of the actual QGIS profile; Flatpak/Snap installations may sandbox the home directory and need different paths or launch settings.

References:
- https://github.com/dtarb/TauDEM/blob/Develop/README.md
- https://github.com/dtarb/TauDEM/blob/Develop/src/CMakeLists.txt
- https://hydrology.usu.edu/taudem/taudem5/TauDEM53CommandLineGuide.pdf
- https://docs.qgis.org/3.44/en/docs/pyqgis_developer_cookbook/processing.html
