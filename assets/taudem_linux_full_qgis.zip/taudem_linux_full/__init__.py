"""QGIS Python plugin entrypoint."""

def classFactory(iface):
    from .plugin import TauDEMLinuxPlugin
    return TauDEMLinuxPlugin(iface)
