"""Algorithm wrappers with standard QGIS parameter and destination classes."""
import os
import tempfile
from pathlib import Path

from qgis.core import (
    QgsProcessing, QgsProcessingAlgorithm, QgsProcessingException,
    QgsProcessingParameterRasterLayer, QgsProcessingParameterVectorLayer,
    QgsProcessingParameterFile, QgsProcessingParameterRasterDestination,
    QgsProcessingParameterVectorDestination, QgsProcessingParameterFileDestination,
    QgsProcessingParameterNumber, QgsProcessingParameterBoolean,
    QgsProcessingParameterEnum, QgsProcessingParameterString,
    QgsVectorFileWriter, QgsVectorLayer,
)
from .runner import TauDEMRunError, args_from_values, executable_path, mpi_command, run_command


class TauDEMAlgorithm(QgsProcessingAlgorithm):
    def __init__(self, spec):
        super().__init__()
        self.spec = spec

    def name(self):
        return self.spec['name']

    def displayName(self):
        return self.spec['label']

    def group(self):
        return self.spec['group']

    def groupId(self):
        return ''.join(c for c in self.group().lower() if c.isalnum())

    def shortHelpString(self):
        return ('Local TauDEM Develop executable: ' + self.name() + '. ' + self.spec['note'] +
                '\nUse local raster files, preferably GeoTIFF. Vector files are converted to temporary '
                'Shapefiles for compatibility. MPI is used unless the tool is serial. '
                'Advanced tools have not been validated against every Develop revision. '
                'Set TAUDEM_BIN_DIR and TAUDEM_MPIEXEC to override auto-discovery.')

    def createInstance(self):
        return TauDEMAlgorithm(self.spec)

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterNumber(
            'CORES', 'MPI processes', QgsProcessingParameterNumber.Integer,
            defaultValue=2, minValue=1, maxValue=256))
        for kind, flag, label, optional, default in self.spec['fields']:
            key = flag.upper().replace('-', '_')
            if kind == 'r':
                p = QgsProcessingParameterRasterLayer(key, label, optional=optional)
            elif kind == 'v':
                p = QgsProcessingParameterVectorLayer(key, label, optional=optional)
            elif kind == 'f':
                p = QgsProcessingParameterFile(key, label, behavior=QgsProcessingParameterFile.File,
                                                optional=optional)
            elif kind == 'or':
                p = QgsProcessingParameterRasterDestination(key, label, optional=optional,
                                                            createByDefault=not optional)
            elif kind == 'ov':
                geom = QgsProcessing.TypeVectorLine if flag == 'net' else QgsProcessing.TypeVectorPoint
                p = QgsProcessingParameterVectorDestination(key, label, type=geom,
                                                            optional=optional, createByDefault=not optional)
            elif kind == 'of':
                extension = '.dat' if flag in ('tree','coord') else '.txt' if flag in ('drp', 'id') else '.csv'
                p = QgsProcessingParameterFileDestination(key, label,
                    fileFilter='File (*%s)' % extension, optional=optional,
                    createByDefault=not optional)
            elif kind == 'str':
                p = QgsProcessingParameterString(key, label, defaultValue=default, optional=optional)
            elif kind == 'bool':
                p = QgsProcessingParameterBoolean(key, label, defaultValue=default)
            elif kind == 'enum':
                p = QgsProcessingParameterEnum(key, label, options=default[0], defaultValue=default[1])
            elif kind in ('int', 'num'):
                num_type = (QgsProcessingParameterNumber.Integer if kind == 'int'
                            else QgsProcessingParameterNumber.Double)
                p = QgsProcessingParameterNumber(key, label, type=num_type,
                                                 defaultValue=default, optional=optional)
            else:
                raise RuntimeError('Bad TauDEM specification: ' + str(kind))
            self.addParameter(p)

    @staticmethod
    def _local_raster(layer):
        if layer is None or not layer.isValid():
            raise QgsProcessingException('Raster parameter invalid')
        # TauDEM calls GDAL directly; the raster needs a real pathname.
        path = layer.source().split('|', 1)[0]
        if not os.path.isfile(path):
            raise QgsProcessingException('TauDEM needs a file-backed local raster, not WMS / memory: ' + path)
        return os.path.abspath(path)

    @staticmethod
    def _write_shapefile(layer, path, context):
        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = 'ESRI Shapefile'
        options.fileEncoding = 'UTF-8'
        res = QgsVectorFileWriter.writeAsVectorFormatV3(
            layer, path, context.transformContext(), options)
        if res[0] != QgsVectorFileWriter.NoError:
            raise QgsProcessingException('Could not export vector input to Shapefile: ' + str(res))

    @staticmethod
    def _convert_vector(shp_path, destination, context):
        if destination.lower().endswith('.shp'):
            return destination
        if '|' in destination or destination.startswith('memory:'):
            raise QgsProcessingException('Vector output must be a local .shp or .gpkg file: ' + destination)
        if not destination.lower().endswith('.gpkg'):
            raise QgsProcessingException('Choose .shp or .gpkg for vector output: ' + destination)
        source = QgsVectorLayer(shp_path, 'TauDEM temporary vector', 'ogr')
        if not source.isValid():
            raise QgsProcessingException('TauDEM intermediate shapefile invalid: ' + shp_path)
        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = 'GPKG'
        options.fileEncoding = 'UTF-8'
        result = QgsVectorFileWriter.writeAsVectorFormatV3(
            source, destination, context.transformContext(), options)
        if result[0] != QgsVectorFileWriter.NoError:
            raise QgsProcessingException('Unable to export TauDEM output to GPKG: ' + str(result))
        return destination

    def processAlgorithm(self, parameters, context, feedback):
        values, results, conversions = {}, {}, []
        temp_dir = tempfile.TemporaryDirectory(prefix='qgis_taudem_')
        try:
            root = Path(temp_dir.name)
            for kind, flag, _label, optional, default in self.spec['fields']:
                key = flag.upper().replace('-', '_')
                if kind == 'r':
                    layer = self.parameterAsRasterLayer(parameters, key, context)
                    values[flag] = self._local_raster(layer) if layer else None
                elif kind == 'v':
                    layer = self.parameterAsVectorLayer(parameters, key, context)
                    if layer:
                        dest = str(root / ('input_' + key.lower() + '.shp'))
                        self._write_shapefile(layer, dest, context)
                        values[flag] = dest
                    else:
                        values[flag] = None
                elif kind == 'f':
                    values[flag] = self.parameterAsFile(parameters, key, context) or None
                elif kind == 'str':
                    values[flag] = self.parameterAsString(parameters, key, context)
                elif kind == 'bool':
                    values[flag] = self.parameterAsBool(parameters, key, context)
                elif kind == 'enum':
                    values[flag] = self.parameterAsEnum(parameters, key, context)
                elif kind == 'int':
                    values[flag] = self.parameterAsInt(parameters, key, context)
                elif kind == 'num':
                    values[flag] = self.parameterAsDouble(parameters, key, context)
                elif kind in ('or', 'ov', 'of'):
                    dest = self.parameterAsOutputLayer(parameters, key, context)
                    if not dest:
                        values[flag] = None
                        continue
                    if dest == 'TEMPORARY_OUTPUT':
                        dest = str(Path(context.temporaryFolder()) / (self.name() + '_' + flag +
                                    ('.tif' if kind == 'or' else '.shp' if kind == 'ov' else '.csv')))
                    if '|' in dest or dest.startswith('memory:'):
                        raise QgsProcessingException('Only local file output destinations are supported: ' + dest)
                    os.makedirs(os.path.dirname(os.path.abspath(dest)), exist_ok=True)
                    if kind == 'or' and not dest.lower().endswith(('.tif', '.tiff')):
                        raise QgsProcessingException('Output raster must be GeoTIFF (.tif): ' + dest)
                    if kind == 'ov':
                        if not dest.lower().endswith(('.shp', '.gpkg')):
                            raise QgsProcessingException('Vector output must be .shp or .gpkg: ' + dest)
                        # TauDEM writes Shapefiles; preserve QGIS-requested destination.
                        raw = dest if dest.lower().endswith('.shp') else str(root / ('output_' + flag + '.shp'))
                        if raw != dest:
                            conversions.append((raw, dest))
                    else:
                        raw = dest
                    values[flag] = raw
                    results[key] = dest
            if self.name() == 'siregion' and values.get('parreg-in') and values.get('shp'):
                raise QgsProcessingException('siregion: choose either region raster or region polygons, not both')
            argv = args_from_values(self.spec, values)
            executable = executable_path(self.name())
            cores = self.parameterAsInt(parameters, 'CORES', context)
            command = mpi_command(executable, argv, cores, serial=self.spec['serial'])
            feedback.pushInfo('TauDEM executable: ' + executable)
            if self.spec['serial']:
                feedback.pushInfo('This command runs without MPI as required by tool.')
            run_command(command, feedback)
            for flag in self.spec['fields']:
                kind, key, _, _, _ = flag
                if kind not in ('or', 'ov', 'of'):
                    continue
                path = values.get(key)
                if path and not os.path.isfile(path):
                    raise QgsProcessingException('TauDEM completed but output missing: ' + path)
            for source, dest in conversions:
                self._convert_vector(source, dest, context)
            feedback.setProgress(100)
            return results
        except (TauDEMRunError, OSError, ValueError) as e:
            raise QgsProcessingException(str(e)) from e
        finally:
            temp_dir.cleanup()
