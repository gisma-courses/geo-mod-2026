"""QGIS provider lifecycle (keeps legacy taudem_local untouched)."""
from qgis.core import QgsApplication
from .provider import TauDEMLinuxProvider

class TauDEMLinuxPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.provider = None

    def initGui(self):
        provider = TauDEMLinuxProvider()
        if not QgsApplication.processingRegistry().addProvider(provider):
            raise RuntimeError('TauDEM Linux: provider registration failed. See QGIS Python log.')
        self.provider = provider

    def unload(self):
        if self.provider is not None:
            QgsApplication.processingRegistry().removeProvider(self.provider)
            self.provider = None
