"""QGIS Processing registration for available TauDEM binaries."""
from qgis.core import QgsProcessingProvider
from .specs import SPECS
from .algorithm import TauDEMAlgorithm


class TauDEMLinuxProvider(QgsProcessingProvider):
    def id(self):
        return 'taudem_linux_full'

    def name(self):
        return 'TauDEM Linux (Develop)'

    def longName(self):
        return 'TauDEM Linux – local MPI executables'

    def loadAlgorithms(self):
        for spec in SPECS:
            self.addAlgorithm(TauDEMAlgorithm(spec))
