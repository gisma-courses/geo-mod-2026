"""Pure Python command construction and Linux MPI execution (no qgis import).

Kept separate to allow unit tests and safe subprocess command inspection.
"""
import os
import selectors
import shlex
import shutil
import signal
import subprocess
from pathlib import Path

STAT_OPTIONS = ('ave', 'min', 'max')
DIST_OPTIONS = ('h', 'v', 'p', 's')


class TauDEMRunError(RuntimeError):
    pass


def executable_path(name, bindir=None):
    folder = Path(bindir or os.environ.get('TAUDEM_BIN_DIR') or (Path.home() / 'apps/taudem/bin')).expanduser()
    for candidate in (folder / name, Path.home() / 'apps/taudem/taudem/bin' / name,
                      Path.home() / 'apps/taudem/taudem' / 'bin' / name):
        if candidate.is_file() and os.access(candidate, os.X_OK):
            return str(candidate)
    raise TauDEMRunError('TauDEM executable not found: ' + name + '\nLooked in: ' + str(folder) +
                         '. Set TAUDEM_BIN_DIR if installed elsewhere.')


def mpi_command(executable, argv, cores=2, serial=False):
    if serial:
        return [executable] + list(argv)
    launcher = os.environ.get('TAUDEM_MPIEXEC') or shutil.which('mpiexec') or shutil.which('mpirun')
    if not launcher:
        raise TauDEMRunError('MPI launcher not found. Install openmpi-bin or set TAUDEM_MPIEXEC.')
    if int(cores) < 1:
        raise TauDEMRunError('MPI process count must be positive')
    return [launcher, '-n', str(int(cores)), executable] + list(argv)


def args_from_values(spec, values):
    """values keys are flag names. Inputs and outputs are already resolved to paths."""
    argv, grouped = [], {}
    fields = {field[1]: field for field in spec['fields']}
    for kind, flag, _label, optional, default in spec['fields']:
        value = values.get(flag)
        if kind == 'bool':
            if value:
                argv.append('-' + flag)
            continue
        if value is None or value == '':
            if not optional:
                raise TauDEMRunError(f'{spec["name"]}: missing required field -{flag}')
            continue
        if flag in spec['par']:
            if kind == 'enum':
                value = ('log', 'arith')[int(value)]
            grouped[flag] = str(value)
            continue
        if flag in spec['method']:
            grouped[flag] = str(value)
            continue
        if kind == 'enum':
            raise TauDEMRunError(f'Unsupported standalone enum flag {flag}')
        argv += ['-' + flag, str(value)]
    if spec['par']:
        argv += ['-par'] + [grouped[f] for f in spec['par']]
    if spec['method']:
        stat = STAT_OPTIONS[int(grouped[spec['method'][0]])]
        dist = DIST_OPTIONS[int(grouped[spec['method'][1]])]
        argv += ['-m', stat, dist]
    return argv


def run_command(cmd, feedback):
    """Read stdout without blocking cancel checks. SIGTERM all MPI ranks via process group."""
    feedback.pushInfo('TauDEM command: ' + shlex.join(cmd))
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, bufsize=1, start_new_session=True)
    tail = []
    sel = selectors.DefaultSelector()
    try:
        sel.register(proc.stdout, selectors.EVENT_READ)
        while proc.poll() is None or sel.get_map():
            if feedback.isCanceled():
                raise TauDEMRunError('TauDEM process cancelled by user.')
            events = sel.select(0.2)
            for key, _ in events:
                line = key.fileobj.readline()
                if line == '':
                    sel.unregister(key.fileobj)
                    continue
                line = line.rstrip('\r\n')
                if line:
                    feedback.pushInfo(line)
                    tail.append(line)
                    if len(tail) > 30:
                        tail.pop(0)
        status = proc.wait()
        if status:
            raise TauDEMRunError('TauDEM failed (exit status %s). Last messages:\n%s' %
                                 (status, '\n'.join(tail[-12:])))
    finally:
        if proc.poll() is None:
            try:
                os.killpg(proc.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                proc.wait()
        sel.close()
        proc.stdout.close()
