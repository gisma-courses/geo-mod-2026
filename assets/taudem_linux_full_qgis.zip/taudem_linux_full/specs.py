"""TauDEM Develop command-line interfaces. Original wrapper definitions.

Sources: official TauDEM 5.3 CLI help (USU), plus Develop/src/*mn.cpp.
Do not assume every upstream binary has identical behavior across commits.
"""


def R(flag, label, optional=False):
    return ('r', flag, label, optional, None)


def V(flag, label, optional=False):
    return ('v', flag, label, optional, None)


def F(flag, label, optional=False):
    return ('f', flag, label, optional, None)


def OR(flag, label, optional=False):
    return ('or', flag, label, optional, None)


def OV(flag, label, optional=False):
    return ('ov', flag, label, optional, None)


def OF(flag, label, optional=False):
    return ('of', flag, label, optional, None)


def N(flag, label, default, integer=False, optional=False):
    return ('int' if integer else 'num', flag, label, optional, default)


def B(flag, label, default=False):
    return ('bool', flag, label, True, default)


def E(flag, label, choices, default=0):
    return ('enum', flag, label, False, (choices, default))


def S(flag, label, default='', optional=False):
    return ('str', flag, label, optional, default)


def P(name, label, group, fields, par=(), method=(), note='', serial=False, layer_flags=True):
    return {
        'name': name, 'label': label, 'group': group, 'fields': fields,
        'par': par, 'method': method, 'note': note,
        'serial': serial, 'layer_flags': layer_flags,
    }


# Flags and multi-value -par/-m are taken from TauDEM CLI documentation.
# R/V/F=input raster/vector/file, OR/OV/OF=output raster/vector/file.
# For output layers, native filenames are used (GeoTIFF, ESRI Shapefile).
SPECS = [
    P('pitremove', 'Pit Remove – depression filling', 'DEM preparation', [
        R('z', 'Input DEM'), R('depmask', 'Optional depression mask', True),
        B('4way', 'Use four-way neighbors'), OR('fel', 'Depression-filled DEM')]),
    P('d8flowdir', 'D8 Flow Directions', 'DEM preparation', [
        R('fel', 'Filled DEM'), OR('p', 'D8 flow direction'), OR('sd8', 'D8 slope')]),
    P('dinfflowdir', 'D-Infinity Flow Directions', 'DEM preparation', [
        R('fel', 'Filled DEM'), OR('ang', 'D-infinity flow angle'), OR('slp', 'D-infinity slope')]),
    P('aread8', 'D8 Contributing Area', 'Flow accumulation', [
        R('p', 'D8 flow direction'), V('o', 'Outlet points', True), R('wg', 'Optional cell weights', True),
        B('nc', 'Disable edge contamination'), OR('ad8', 'D8 contributing area')]),
    P('areadinf', 'D-Infinity Contributing Area', 'Flow accumulation', [
        R('ang', 'D-infinity flow angle'), V('o', 'Outlet points', True), R('wg', 'Optional cell weights', True),
        B('nc', 'Disable edge contamination'), OR('sca', 'Specific catchment area')]),
    P('gridnet', 'Grid Network – path lengths and Strahler order', 'Flow accumulation', [
        R('p', 'D8 flow direction'), V('o', 'Outlet points', True),
        R('mask', 'Domain mask raster', True), N('thresh', 'Mask threshold (only with mask)', 0),
        OR('plen', 'Longest upslope path'), OR('tlen', 'Total upslope path'),
        OR('gord', 'Strahler order')]),
    P('peukerdouglas', 'Peuker–Douglas stream source', 'Stream extraction', [
        R('fel', 'Elevation grid'), N('PAR0', 'Center smoothing weight', 0.4),
        N('PAR1', 'Side smoothing weight', 0.1), N('PAR2', 'Diagonal smoothing weight', 0.05),
        OR('ss', 'Stream source indicator')], par=('PAR0', 'PAR1', 'PAR2')),
    P('threshold', 'Stream Definition by Threshold', 'Stream extraction', [
        R('ssa', 'Accumulated stream source'), R('mask', 'Optional domain mask', True),
        N('thresh', 'Stream threshold', 100.0), OR('src', 'Stream raster')]),
    P('lengtharea', 'Length–Area stream source', 'Stream extraction', [
        R('plen', 'Longest upslope path'), R('ad8', 'D8 contributing area'),
        N('PAR0', 'Multiplier M', 0.03), N('PAR1', 'Exponent y', 1.3),
        OR('ss', 'Stream source grid')], par=('PAR0', 'PAR1')),
    P('slopearea', 'Slope–Area combination', 'Stream extraction', [
        R('slp', 'Slope'), R('sca', 'Specific catchment area'),
        N('PAR0', 'Slope exponent m', 2), N('PAR1', 'Area exponent n', 1),
        OR('sa', 'Slope-area indicator')], par=('PAR0', 'PAR1')),
    P('d8flowpathextremeup', 'D8 Extreme Upslope Value', 'Stream extraction', [
        R('p', 'D8 flow direction'), R('sa', 'Upslope value grid'),
        V('o', 'Outlet points', True), B('min', 'Use minimum (default maximum)'),
        B('nc', 'Disable edge contamination'), OR('ssa', 'Extreme upslope values')]),
    P('dropanalysis', 'Stream Drop Analysis', 'Stream extraction', [
        R('fel', 'Filled DEM'), R('p', 'D8 flow direction'),
        R('ad8', 'D8 contributing area'), R('ssa', 'Accumulated stream source'),
        V('o', 'Outlet points (required)'),
        N('PAR0', 'Minimum threshold', 5), N('PAR1', 'Maximum threshold', 500),
        N('PAR2', 'Number of thresholds', 10, integer=True),
        E('PAR3', 'Threshold spacing', ['Logarithmic', 'Arithmetic']),
        OF('drp', 'Drop analysis statistics (.txt)')], par=('PAR0', 'PAR1', 'PAR2', 'PAR3')),
    P('streamnet', 'Stream Network and Watersheds', 'Stream networks', [
        R('fel', 'Filled DEM'), R('p', 'D8 flow direction'),
        R('ad8', 'D8 contributing area'), R('src', 'Stream raster'),
        V('o', 'Outlet points (must contain id)', True), B('sw', 'Delineate single watershed'),
        OR('ord', 'Strahler stream order'), OF('tree', 'Network tree (.dat)'),
        OF('coord', 'Network coordinates (.dat)'), OV('net', 'Stream network (.shp)'),
        OR('w', 'Reach watersheds')],
        note='Outlet point data must contain integer attribute id. Stream network vector output: choose .shp.'),
    P('gagewatershed', 'Gage Watersheds', 'Stream networks', [
        R('p', 'D8 flow direction'), V('o', 'Gage locations (id field)'),
        OR('gw', 'Gage watershed raster'), OF('id', 'Downstream connectivity (.txt)', True)]),
    P('moveoutletstostreams', 'Move Outlets to Streams', 'Stream networks', [
        R('p', 'D8 flow direction'), R('src', 'Stream raster'),
        V('o', 'Original outlet points'), N('md', 'Maximum move distance (cells)', 50, integer=True),
        OV('om', 'Moved outlet points (.shp)')]),
    P('connectdown', 'Connect Down – downstream outlet links', 'Stream networks', [
        R('p', 'D8 flow direction'), R('ad8', 'D8 contributing area'), R('w', 'Watershed IDs'),
        N('d', 'Move downstream cells', 1, integer=True),
        OV('o', 'Original outlet points (.shp)'), OV('od', 'Moved outlet points (.shp)')]),
    P('catchoutlets', 'Catchment Outlets from stream network', 'Stream networks', [
        R('p', 'D8 flow direction'), V('net', 'Stream network vector'),
        N('mindist', 'Minimum distance between outlets', 0.0),
        N('minarea', 'Minimum catchment area', 0.0),
        N('gwstartno', 'First watershed ID', 1, integer=True),
        OV('o', 'Catchment outlet points (.shp)')], layer_flags=False),
    P('dinfrevaccum', 'D-Infinity Reverse Accumulation', 'Transport and dependence', [
        R('ang', 'D-infinity flow angle'), R('wg', 'Weights or loading'),
        OR('racc', 'Reverse accumulation'), OR('dmax', 'Maximum downslope values')]),
    P('dinfupdependence', 'D-Infinity Upslope Dependence', 'Transport and dependence', [
        R('ang', 'D-infinity flow angle'), R('dg', 'Destination zone indicator'),
        OR('dep', 'Upslope dependence')]),
    P('dinfdecayaccum', 'D-Infinity Decaying Accumulation', 'Transport and dependence', [
        R('ang', 'D-infinity flow angle'), R('dm', 'Decay multipliers'),
        R('wg', 'Optional weight grid', True), V('o', 'Outlet points', True),
        B('nc', 'Disable edge contamination'), OR('dsca', 'Decayed contributing area')]),
    P('dinfconclimaccum', 'D-Infinity Concentration Limited Accumulation', 'Transport and dependence', [
        R('ang', 'D-infinity flow angle'), R('dg', 'Disturbance indicator'),
        R('dm', 'Decay multiplier'), R('wg', 'Effective runoff / weight raster', True),
        V('o', 'Outlet points', True), N('csol', 'Concentration threshold', 1),
        B('nc', 'Disable edge contamination'), OR('ctpt', 'Concentration'), OR('q', 'Specific discharge')]),
    P('dinftranslimaccum', 'D-Infinity Transport Limited Accumulation', 'Transport and dependence', [
        R('ang', 'D-infinity flow angle'), R('tsup', 'Supply / erosion raster'),
        R('tc', 'Transport capacity raster'),
        R('cs', 'Input concentration (optional)', True),
        V('o', 'Outlet points', True), B('nc', 'Disable edge contamination'),
        OR('tla', 'Transport limited accumulation'), OR('tdep', 'Deposition'),
        OR('ctpt', 'Output concentration (requires CS input)', True)],
        note='Specify output CTPT only when providing input concentration CS.'),
    P('retlimflow', 'Retention Limited Runoff', 'Transport and dependence', [
        R('ang', 'D-infinity flow angle'), R('wg', 'Runoff / weight raster'),
        R('rc', 'Retention capacity raster'), OR('qrl', 'Retention limited runoff')]),
    P('dinfdistdown', 'D-Infinity Distance Down (incl. vertical HAND)', 'Distance and terrain indices', [
        R('ang', 'D-infinity flow angle'), R('fel', 'Elevation grid'),
        R('src', 'Stream raster'), R('wg', 'Optional path weight grid', True),
        E('MSTAT', 'Statistical method', ['Average', 'Minimum', 'Maximum']),
        E('MDIST', 'Distance', ['Horizontal', 'Vertical', 'Pythagoras', 'Surface']),
        B('nc', 'Disable edge contamination'), OR('dd', 'Downslope distance / HAND')],
        method=('MSTAT', 'MDIST')),
    P('dinfdistup', 'D-Infinity Distance Up', 'Distance and terrain indices', [
        R('ang', 'D-infinity flow angle'), R('fel', 'Elevation grid'),
        R('slp', 'D-infinity slope'), N('thresh', 'Flow proportion threshold', 0),
        E('MSTAT', 'Statistical method', ['Average', 'Minimum', 'Maximum']),
        E('MDIST', 'Distance', ['Horizontal', 'Vertical', 'Pythagoras', 'Surface']),
        B('nc', 'Disable edge contamination'), OR('du', 'Upslope distance to ridge')],
        method=('MSTAT', 'MDIST')),
    P('d8hdisttostrm', 'D8 Distance To Streams', 'Distance and terrain indices', [
        R('p', 'D8 flow direction'), R('src', 'Stream indicator or count raster'),
        N('thresh', 'Stream cell threshold', 1, integer=True),
        OR('dist', 'D8 distance to stream')]),
    P('slopeavedown', 'D8 Slope Average Down', 'Distance and terrain indices', [
        R('fel', 'Elevation grid'), R('p', 'D8 flow direction'),
        N('dn', 'Downslope distance (map units)', 100.0),
        OR('slpd', 'Distance-averaged slope')]),
    P('slopearearatio', 'Slope / Area Ratio', 'Distance and terrain indices', [
        R('slp', 'Slope'), R('sca', 'Specific catchment area'), OR('sar', 'Slope-area ratio')]),
    P('twi', 'Topographic Wetness Index (TWI)', 'Distance and terrain indices', [
        R('slp', 'Slope'), R('sca', 'Specific catchment area'), OR('twi', 'Topographic wetness index')]),
    P('dinfavalanche', 'D-Infinity Avalanche Runout', 'Distance and terrain indices', [
        R('ang', 'D-infinity flow angle'), R('fel', 'Elevation grid'),
        R('ass', 'Source area raster'), N('thresh', 'Minimum proportion threshold', 0.2),
        N('alpha', 'Minimum alpha angle', 18), B('direct', 'Use straight line source distance'),
        OR('rz', 'Runout zone'), OR('dfs', 'Downslope path length')]),
    P('catchhydrogeo', 'Catchment Hydraulic Geometry – rating curves', 'HAND and flooding', [
        R('hand', 'Height above nearest drainage (HAND)'), R('catch', 'Catchment ID raster'),
        F('catchlist', 'Catchment ID / slope / length CSV'), R('slp', 'Slope raster'),
        F('h', 'Stage height table CSV/TXT'), OF('table', 'Hydraulic geometry table (.csv)')]),
    P('inundepth', 'Inundation Depth from HAND and discharge', 'HAND and flooding', [
        R('hand', 'Height above nearest drainage (HAND)'), R('catch', 'Catchment IDs'),
        R('mask', 'Optional exclusion mask', True), F('fc', 'Forecast flow table (.csv)'),
        F('hp', 'Hydraulic property table (.csv)'), OR('inun', 'Inundation depth'),
        OF('depth', 'Reach depth table (.csv)', True)]),
    P('sinmapsi', 'SINMAP Stability Index', 'SINMAP and raster utilities', [
        R('slp', 'Slope'), R('sca', 'Specific catchment area'),
        R('cal', 'Parameter region ID raster'), F('calpar', 'Parameter attribute table'),
        N('PAR0', 'Minimum terrain recharge (m/hr)', 0.0009),
        N('PAR1', 'Maximum terrain recharge (m/hr)', 0.00135),
        N('PAR2', 'Gravitational acceleration', 9.81),
        N('PAR3', 'Water density', 1000.0),
        OR('si', 'Stability index'), OR('sat', 'Saturation index')],
        par=('PAR0', 'PAR1', 'PAR2', 'PAR3')),
    P('siregion', 'SINMAP Parameter Regions (siregion)', 'SINMAP and raster utilities', [
        R('dem', 'Reference DEM'), R('parreg-in', 'Optional region ID raster', True),
        V('shp', 'Optional region polygons (instead of raster)', True),
        S('shp-att-name', 'Polygon ID attribute name', 'ID'),
        N('att-tmin', 'Transmissivity minimum', 2.708),
        N('att-tmax', 'Transmissivity maximum', 2.708),
        N('att-cmin', 'Cohesion minimum', 0.0), N('att-cmax', 'Cohesion maximum', 0.25),
        N('att-phimin', 'Friction angle minimum (deg)', 30),
        N('att-phimax', 'Friction angle maximum (deg)', 45),
        N('att-soildens', 'Soil density (kg/m³)', 2000),
        OR('parreg', 'Parameter region grid'), OF('att', 'Parameter table (.csv)')],
        note='Without region inputs creates one region. Polygon requires the named ID attribute; raster and polygon region inputs are mutually exclusive.',
        serial=True),
    P('flowdircond', 'Flow Direction Conditioning', 'SINMAP and raster utilities', [
        R('z', 'Elevation grid'), R('p', 'D8 flow direction'),
        OR('zfdc', 'Flow direction conditioned elevation')]),
    P('editraster', 'Edit Raster using change coordinate table', 'SINMAP and raster utilities', [
        R('in', 'Raster to edit'), F('changes', 'Coordinate and replacement value text (x,y,value)'),
        OR('out', 'Edited raster')]),
    P('setregion', 'Set Region using gage watersheds', 'SINMAP and raster utilities', [
        R('p', 'D8 flow direction'), R('gw', 'Gage watershed/region raster'),
        N('id', 'Region identifier', 1, integer=True), OR('out', 'Output region raster')]),
]

EXPECTED_EXECUTABLES = (
    'aread8', 'areadinf', 'd8flowdir', 'd8flowpathextremeup', 'd8hdisttostrm',
    'dinfavalanche', 'dinfconclimaccum', 'dinfdecayaccum', 'dinfdistdown', 'dinfdistup',
    'dinfflowdir', 'dinfrevaccum', 'dinftranslimaccum', 'dinfupdependence', 'dropanalysis',
    'gridnet', 'lengtharea', 'moveoutletstostreams', 'peukerdouglas', 'pitremove',
    'slopearea', 'slopearearatio', 'slopeavedown', 'streamnet', 'threshold', 'gagewatershed',
    'twi', 'connectdown', 'catchhydrogeo', 'catchoutlets', 'editraster', 'flowdircond',
    'retlimflow', 'setregion', 'sinmapsi', 'inundepth', 'siregion',
)
